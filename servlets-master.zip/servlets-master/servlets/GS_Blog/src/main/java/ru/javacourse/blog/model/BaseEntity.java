package ru.javacourse.blog.model;

/**
 * Author: Georgy Gobozov
 * Date: 21.04.13
 */
public class BaseEntity {

    protected Integer id;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }
}
