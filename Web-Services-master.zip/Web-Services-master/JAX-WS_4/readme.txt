1) service - mvm clean package
2) client - mvn clean package
3) builder - mvn clean package
4) deploy
5) Open wsdl http://localhost:8080/webservice/calculator?wsdl
6) Launch servlet http://localhost:8080/client/