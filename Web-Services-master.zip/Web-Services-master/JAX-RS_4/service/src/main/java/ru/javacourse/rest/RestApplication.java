package ru.javacourse.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import java.util.Set;

/**
 * Created by Georgy Gobozov on 11.02.2015.
 */
@ApplicationPath("/rest")
public class RestApplication extends Application{

}
