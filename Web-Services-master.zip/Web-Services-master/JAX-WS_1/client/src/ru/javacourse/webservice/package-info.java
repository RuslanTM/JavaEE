@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservice.javacourse.ru/")
package ru.javacourse.webservice;
