Simple webservice example. Publish via Endpoint class and access Via Service class or use wsimport to generate client

