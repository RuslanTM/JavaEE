@javax.xml.bind.annotation.XmlSchema(namespace = "http://webservice.javacourse.edu/")
package edu.javacourse.webservice;
