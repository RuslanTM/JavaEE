1) Ejb bean as web service - just add webservice annotation
2) Build and deploy on glassfish or jboss
3) Test with soapUI